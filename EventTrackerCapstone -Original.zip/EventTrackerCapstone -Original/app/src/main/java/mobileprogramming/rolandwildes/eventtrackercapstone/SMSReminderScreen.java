package mobileprogramming.rolandwildes.eventtrackercapstone;
/**
 * The following code is for sms messaging.
 *
 * Currently not being used. This was required for the original assignment but
 * makes little sense for a personal event tracker. May change to a pop notification when an
 * event is close.
 */
/* TODO change the sms notification to show after login

 */
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class SMSReminderScreen extends AppCompatActivity {
    Button smsAllow,smsDeny;
    static final String CHANNEL_ID = "channelID";
    NotificationManagerCompat notificationsManager;

    String phoneNumber;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notification);
        notificationsManager = NotificationManagerCompat.from(this);
        smsAllow = findViewById(R.id.smsAllow);
        smsDeny = findViewById(R.id.smsDeny);
        phoneNumber = "";
        createNotificationChannel();
        askPermissionAndGetPhoneNumbers();
        smsAllow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                smsTextMessage();
                smsNotification();
                Intent newPage = new Intent(getApplicationContext(),EventScreen.class);
                startActivity(newPage);
            }
        });

        smsDeny.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent newPage = new Intent(getApplicationContext(),EventScreen.class);
                startActivity(newPage);
            }
        });

    }

    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notification1";
            String description = "SMS ENABLED";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void smsNotification() {

        Intent notificationIntent = new Intent(this,SMSReminderScreen.class);
        PendingIntent contentIntent = PendingIntent.getActivity(this,0,notificationIntent,PendingIntent.FLAG_UPDATE_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this,CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_bell)
                .setContentTitle("EVENT SMS")
                .setContentText("SMS notifications enabled for new event")
                .setContentIntent(contentIntent);

        builder.setContentIntent(contentIntent);
        NotificationManagerCompat manager = NotificationManagerCompat.from(this);
        manager.notify(0,builder.build());

    }

    private void smsTextMessage(){
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_DENIED) {
                Log.d("permission", "permission denied to SEND_SMS - requesting it");
                String[] permissions = {Manifest.permission.SEND_SMS};
                requestPermissions(permissions, 1);
            }
        }
        SmsManager smsTextManager = SmsManager.getDefault();
        smsTextManager.sendTextMessage(phoneNumber,null,"Notifications enabled",null,null);
    }

    private void askPermissionAndGetPhoneNumbers() {

        // With Android Level >= 23, you have to ask the user
        // for permission to get Phone Number.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) { // 23

            // Check if we have READ_PHONE_STATE permission
            int readPhoneStatePermission = ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.READ_PHONE_STATE);

            if ( readPhoneStatePermission != PackageManager.PERMISSION_GRANTED) {
                // If don't have permission so prompt the user.
                this.requestPermissions(
                        new String[]{Manifest.permission.READ_PHONE_STATE},
                        1
                );
                return;
            }
        }
        this.getPhoneNumbers();
    }

    // Need to ask user for permission: android.permission.READ_PHONE_STATE
    @SuppressLint("MissingPermission")
    private void getPhoneNumbers() {
        try {
            TelephonyManager manager = (TelephonyManager) this.getSystemService(Context.TELEPHONY_SERVICE);

            String phoneNumber1 = manager.getLine1Number();

            phoneNumber = phoneNumber1;

        } catch (Exception ex) {

        }
    }
}
