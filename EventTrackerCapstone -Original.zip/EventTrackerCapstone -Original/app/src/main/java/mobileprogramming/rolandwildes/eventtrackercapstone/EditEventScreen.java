package mobileprogramming.rolandwildes.eventtrackercapstone;
/**
 * The following code handles the editing of an event. Creates a window with modifiable fields and saves the changes to the database.
 */

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//Functionality for editing an event in the database
public class EditEventScreen extends AppCompatActivity {

    Button saveEditButton;
    EditText editEventDate,editEventDetails;
    EventDatabase db;
    EventModel eventModel;
    Switch sms;
    SharedPreferences sp;
    String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_event_screen);
        //find buttons and text fields
        saveEditButton = findViewById(R.id.saveEditButton);
        editEventDate = findViewById(R.id.editEventDate);
        editEventDetails = findViewById(R.id.editEventDetails);
        sms = findViewById(R.id.smsEditSwitch);
        db = new EventDatabase(EditEventScreen.this);
        sp = getApplicationContext().getSharedPreferences("CurrentUser", Context.MODE_PRIVATE);
        user = sp.getString("User","");
        editEventDate.setText(getIntent().getStringExtra("eventDate"));
        editEventDetails.setText(getIntent().getStringExtra("eventDetails"));
        sms.setChecked(getIntent().getExtras().getBoolean("eventSMS"));

        //save button
        saveEditButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                try{
                    //call update event method when button is pressed
                    eventModel = new EventModel(getIntent().getIntExtra("id",-1),editEventDate.getText().toString(),editEventDetails.getText().toString(),sms.isChecked());
                    db.updateEvent(eventModel,user);
                    Intent newEventScreen = new Intent(getApplicationContext(), EventScreen.class);
                    startActivity(newEventScreen);

                }
                catch (Exception e){
                    Toast.makeText(EditEventScreen.this,"Failed to update event", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }

}