package mobileprogramming.rolandwildes.eventtrackercapstone;
/**
 * The following code is for the new event screen shown for creating a new event.
 */

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.util.Calendar;
//functionality for adding an event with user input and saving the results to the database
public class NewEventScreen extends AppCompatActivity {

    Button saveNewEvent;
    EditText event_date, event_details;
    Switch sms;
    SharedPreferences sp;
    String user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_event_screen);
        saveNewEvent = findViewById(R.id.saveNewEvent);
        sms = findViewById(R.id.smsNewSwitch);
        event_date = findViewById(R.id.eventDate);
        event_details = findViewById(R.id.eventDetails);
        sp = getApplicationContext().getSharedPreferences("CurrentUser", Context.MODE_PRIVATE);
        user = sp.getString("User","");
        //When the save button is pressed take the user inputs and save them to the database as a new event
        saveNewEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EventModel eventModel;
                try{
                    eventModel = new EventModel(-1,event_date.getText().toString(),event_details.getText().toString(),sms.isChecked());
                    Toast.makeText(NewEventScreen.this,"Added Event", Toast.LENGTH_LONG).show();
                }
                catch (Exception e){
                    eventModel = new EventModel(-1,"NULL","Error creating event",false);
                    Toast.makeText(NewEventScreen.this,"Failed to add event", Toast.LENGTH_SHORT).show();

                }
                EventDatabase event = new EventDatabase(NewEventScreen.this);
                event.addEvent(eventModel,user);

                Intent newPage = new Intent(getApplicationContext(),EventScreen.class);
                startActivity(newPage);
            }
        });

    }
}