package mobileprogramming.rolandwildes.eventtrackercapstone;

/**
 * The following code creates a structure for an event. The data then can be used for adding or modifying an event in the database.
 */
public class EventModel {

    int id;
    String eventDate;
    String eventDetails;
    boolean sms;
    int imgID = R.drawable.ic_launcher_background;

    public EventModel(int id, String eventDate, String eventDetails, boolean sms) {
        this.id = id;
        this.eventDate = eventDate;
        this.eventDetails = eventDetails;
        this.sms = sms;
    }

    public EventModel() {

    }

    @Override
    public String toString() {
        return "EventModel{" +
                "id=" + id +
                ", eventDate=" + eventDate +
                ", eventDetails='" + eventDetails +
                ", sms=" + sms +
                '\'' +
                '}';
    }
    //return id
    public int getId() {
        return id;
    }
    //set id
    public void setId(int id) {
        this.id = id;
    }
    //return event date
    public String getEventDate() {
        return eventDate;
    }
    //set event date
    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }
    //return event details
    public String getEventDetails() {
        return eventDetails;
    }
    //set event details
    public void setEventDetails(String eventDetails) {
        this.eventDetails = eventDetails;
    }
    //return id
    public boolean getSMS() {
        return sms;
    }
    //set id
    public void setSMS(boolean sms) {
        this.sms = sms;
    }
    //return image id
    public int getImgid(){
        return imgID;
    }
}
