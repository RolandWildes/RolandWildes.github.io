package mobileprogramming.rolandwildes.eventtrackercapstone;
/**
 * The following code is for the login screen and is the first code to be run for the program.
 */

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//Main activity for the application. This is the login screen you are greeted with
public class MainActivity extends AppCompatActivity {

    Button loginButton;
    EditText userName, userPassword;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        loginButton = findViewById(R.id.loginButton);

        userName = findViewById(R.id.username);
        userPassword = findViewById(R.id.password);

        sp = getSharedPreferences("CurrentUser", Context.MODE_PRIVATE);
        //check to see if the user is currently in the database otherwise save their login to the database
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserModel userModel;

                try {
                    userModel = new UserModel(-1,userName.getText().toString(),userPassword.getText().toString());
                }
                catch (Exception e)
                {
                    userModel = new UserModel(-1,"Error","Error");
                }

                LoginDatabase2 loginDatabase2 = new LoginDatabase2(MainActivity.this);
                if(!loginDatabase2.getUser(userModel)){
                    System.out.println("New User");
                    loginDatabase2.addUser(userModel);
                    Toast.makeText(MainActivity.this, "New User Added. Welcome!", Toast.LENGTH_LONG).show();

                } else {
                    System.out.println("old user");
                    Toast.makeText(MainActivity.this, "Welcome Back!", Toast.LENGTH_LONG).show();

                }

                SharedPreferences.Editor editor = sp.edit();
                editor.putString("User",userName.getText().toString());
                editor.commit();

                Intent newPage = new Intent(getApplicationContext(),EventScreen.class);
                startActivity(newPage);

            }
        });

        loginButton.setEnabled(false);
        //watch for text change and enable login if there is some username
        userName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                loginButton.setEnabled(!TextUtils.isEmpty(userName.getText()));
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });


    }
}