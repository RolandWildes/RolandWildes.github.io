package mobileprogramming.rolandwildes.eventtrackercapstone;
/**
 * The following code is for the main event screen. This screen takes all of the events in the event database and shows them as individual
 * cards. You can then interact with the cards to view, update or delete the events you want.
 */

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.PopupMenu;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

//Functionality for the event grid view
public class EventScreen extends AppCompatActivity {

    Button addEvent, refreshScreen;
    GridView eventsGrid;
    EventDatabase eventDatabase;
    List<EventModel> events;
    EventAdapter eventAdapterSearch;

    SharedPreferences sp;
    String user;

    public static ArrayList<String> ArrayofName = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_base);

        addEvent = findViewById(R.id.addEventButton);
        refreshScreen = findViewById(R.id.refresh);
        eventsGrid = findViewById(R.id.eventGrid);
        sp = getApplicationContext().getSharedPreferences("CurrentUser", Context.MODE_PRIVATE);
        user = sp.getString("User","");

        displayEventsSortShort();
        //set functionality for adding an event when button is pressed
        addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent newEventScreen = new Intent(getApplicationContext(),NewEventScreen.class);
                startActivity(newEventScreen);
            }
        });
        //set functionality for editing an event when item is pressed in the grid
        eventsGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                EventModel clickedEvent = (EventModel) adapterView.getItemAtPosition(i);
                EventModel eventModel = events.get(i);
                Intent editEventScreen = new Intent(getApplicationContext(),EventDetailsScreen.class);
                editEventScreen.putExtra("id",clickedEvent.getId());
                editEventScreen.putExtra("eventDate",clickedEvent.getEventDate());
                editEventScreen.putExtra("eventDetails",clickedEvent.getEventDetails());
                editEventScreen.putExtra("eventSMS",clickedEvent.getSMS());
                startActivity(editEventScreen);
            }
        });

        refreshScreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent newPage = new Intent(getApplicationContext(),EventScreen.class);
                startActivity(newPage);
            }
        });

        eventsGrid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {

                // Initializing the popup menu and giving the reference as current context
                PopupMenu popupMenu = new PopupMenu(EventScreen.this, eventsGrid);

                // Inflating popup menu from popup_menu.xml file
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {
                        EventModel clickedEvent = (EventModel) adapterView.getItemAtPosition(i);
                        EventModel eventModel = events.get(i);
                        switch(menuItem.getItemId()) {
                            case R.id.editEventPop:

                                Intent editEventScreen = new Intent(getApplicationContext(),EditEventScreen.class);
                                editEventScreen.putExtra("id",clickedEvent.getId());
                                editEventScreen.putExtra("eventDate",clickedEvent.getEventDate());
                                editEventScreen.putExtra("eventDetails",clickedEvent.getEventDetails());
                                editEventScreen.putExtra("eventSMS",clickedEvent.getSMS());
                                //editEventScreen.putExtra("eventSMS",clickedEvent.getSMS());
                                startActivity(editEventScreen);
                                return true;
                            case R.id.deleteEventPop:

                                eventDatabase.deleteEvent(Integer.toString(clickedEvent.id));
                                Intent newPage = new Intent(getApplicationContext(),EventScreen.class);
                                startActivity(newPage);
                                return true;
                            default:
                                return false;

                        }
                    }
                });
                // Showing the popup menu
                popupMenu.show();
                return true;
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
// Inflate menu with items using MenuInflator
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.search_menu, menu);

        // Initialise menu item search bar
        // with id and take its object
        MenuItem searchViewItem = menu.findItem(R.id.nav_search);

        SearchView searchView = (SearchView) searchViewItem.getActionView();

        // attach setOnQueryTextListener
        // to search view defined above
        searchView.setOnQueryTextListener(
                new SearchView.OnQueryTextListener() {

                    @Override
                    public boolean onQueryTextSubmit(String query)
                    {
                        sortEvents(query);
                        return false;
                    }

                    // This method is overridden to filter
                    // the adapter according to a search query
                    // when the user is typing search
                    @Override
                    public boolean onQueryTextChange(String newText)
                    {
                        sortEvents(newText);
                        return false;
                    }
                });

        return super.onCreateOptionsMenu(menu);
    }
    //display all the events in to a grid view
    public void sortEvents(String date){
        try{

            eventDatabase = new EventDatabase(EventScreen.this);
            events = eventDatabase.searchEvents(date,user);
            eventDatabase.searchEvents(date,user);

            eventAdapterSearch = new EventAdapter(this,events);

            eventsGrid.setAdapter(eventAdapterSearch);

        }
        catch (Exception e){
            Toast.makeText(EventScreen.this,"No Events to load", Toast.LENGTH_SHORT).show();
        }

    }

    public void displayEventsSortShort(){
        try{

            eventDatabase = new EventDatabase(EventScreen.this);
            events = eventDatabase.getAllEventsOrderByDate(user);
            eventDatabase.getAllEventsOrderByDate(user);

            EventAdapter eventAdapter = new EventAdapter(this,events);

            eventsGrid.setAdapter(eventAdapter);

        }
        catch (Exception e){
            Toast.makeText(EventScreen.this,"No Events to load", Toast.LENGTH_SHORT).show();
        }

    }


}