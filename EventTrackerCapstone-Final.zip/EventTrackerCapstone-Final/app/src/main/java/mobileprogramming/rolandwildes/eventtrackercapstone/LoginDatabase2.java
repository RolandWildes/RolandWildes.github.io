package mobileprogramming.rolandwildes.eventtrackercapstone;
/**
 * The following code helps create, update, search and delete databases for the user logins.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

//Login database helper for creating and managing the login database
public class LoginDatabase2 extends SQLiteOpenHelper {

    public static final String LOGIN_TABLE = "LOGIN_TABLE";
    public static final String COLUMN_USER_NAME = "USER_NAME";
    public static final String COLUMN_USER_PASSWORD = "USER_PASSWORD";
    public static final String COLUMN_ID = "ID";

    public LoginDatabase2(@Nullable Context context) {
        super(context, "LoginDatabase.db", null, 1);
    }

    //create new table
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + LOGIN_TABLE + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USER_NAME + " TEXT, " + COLUMN_USER_PASSWORD + " TEXT)";
        db.execSQL(createTableStatement);
    }
    //called when database changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE " + LOGIN_TABLE);
        onCreate(db);
    }
    // add user to the database
    public boolean addUser(UserModel userModel){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_USER_NAME, userModel.getUsername());
        cv.put(COLUMN_USER_PASSWORD, userModel.getPassword());

        long insert = db.insert(LOGIN_TABLE, null, cv);
        if(insert == -1){
            return false;
        }else {
            return true;
        }
    }
    //delete user from the database
    public boolean DeleteUser(UserModel userModel){
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + LOGIN_TABLE + " WHERE " + COLUMN_USER_NAME + " = " + userModel.getUsername();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()){
            cursor.close();
            db.close();
            return true;
        } else {
            cursor.close();
            db.close();
            return false;
        }
    }
    //return a user from the database
    public boolean getUser(UserModel userModel){
        SQLiteDatabase db = this.getReadableDatabase();
        String queryString = " SELECT * FROM "+ LOGIN_TABLE + " WHERE " + COLUMN_USER_NAME + " = '" + userModel.getUsername() + "'";
        System.out.println(db.rawQuery(queryString,null));
        Cursor cursor = db.rawQuery(queryString,null);

        String passwordQueryString = " SELECT * FROM "+ LOGIN_TABLE + " WHERE " + COLUMN_USER_PASSWORD + " = '" + userModel.getPassword() + "'";
        System.out.println(db.rawQuery(passwordQueryString,null));
        Cursor passwordCursor = db.rawQuery(passwordQueryString,null);

        if(cursor.moveToFirst() && passwordCursor.moveToFirst()){
            cursor.close();
            db.close();
            return true;
        } else {
            cursor.close();
            db.close();
            return false;
        }
        //return true;
    }
    //return all users from the database
    public List<UserModel> getAllUsers(){

        List<UserModel> returnList = new ArrayList<>();
        //get data
        String queryString = "SELECT * FROM " + LOGIN_TABLE;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString,null);

        if(cursor.moveToFirst()){
            do{
               int userID = cursor.getInt(0);
               String userName = cursor.getString(1);
               String userPassword = cursor.getString(2);

               UserModel newUser = new UserModel(userID,userName,userPassword);
               returnList.add(newUser);
            } while(cursor.moveToNext());

        } else {

        }

        cursor.close();
        db.close();
        return returnList;

    }
}
