package mobileprogramming.rolandwildes.eventtrackercapstone;
/**
 * The following code handles the event view for showing the extra information on a clicked event
 */

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

//Functionality for editing an event in the database
public class EventDetailsScreen extends AppCompatActivity {

    Button eventDetailsBack;
    TextView eventDetailsDate,eventDetailsInformation;
    EventDatabase db;
    Switch sms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_details_screen);
        //find buttons and text fields
        eventDetailsBack = findViewById(R.id.eventDetailsBack);
        eventDetailsDate = findViewById(R.id.eventDetailsDate);
        eventDetailsInformation = findViewById(R.id.eventDetailsInformation);
        sms = findViewById(R.id.eventDetailsSMS);
        db = new EventDatabase(EventDetailsScreen.this);

        eventDetailsDate.setText(getIntent().getStringExtra("eventDate"));
        eventDetailsInformation.setText(getIntent().getStringExtra("eventDetails"));
        sms.setChecked(getIntent().getExtras().getBoolean("eventSMS"));
        sms.setEnabled(false);

        //save button
        eventDetailsBack.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                try{
                    Intent newEventScreen = new Intent(getApplicationContext(), EventScreen.class);
                    startActivity(newEventScreen);

                }
                catch (Exception e){
                    Toast.makeText(EventDetailsScreen.this,"Failed to update event", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }

}