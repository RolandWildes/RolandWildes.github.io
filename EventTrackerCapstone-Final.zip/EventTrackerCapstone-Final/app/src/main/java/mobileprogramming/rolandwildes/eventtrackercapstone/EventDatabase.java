package mobileprogramming.rolandwildes.eventtrackercapstone;
/**
 * The following code helps create, update, search and delete databases for the events.
 */

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;


// Event database functionality
public class EventDatabase extends SQLiteOpenHelper {
    public static final String EVENT_TABLE = "EVENT_TABLE";
    public static final String COLUMN_EVENT_DATE = "EVENT_DATE";
    public static final String COLUMN_EVENT_DETAILS = "EVENT_DETAILS";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_EVENT_SMS = "EVENT_SMS";
    public static final String COLUMN_EVENT_USER = "EVENT_USER";
    public int id;


    public EventDatabase(@Nullable Context context) {
        super(context, "EventDatabase.db", null, 5);
        SQLiteDatabase db = this.getWritableDatabase();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + EVENT_TABLE + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_EVENT_DATE + " DATE, " + COLUMN_EVENT_DETAILS + " TEXT, " + COLUMN_EVENT_SMS + " BOOL, " + COLUMN_EVENT_USER+ " TEXT)";
        db.execSQL(createTableStatement);
        id = 0;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE " + EVENT_TABLE);
        onCreate(db);
    }

    //returns event id
    public int getId(){
        return id;
    }
    //sets event id
    public void setId(int id) {
        this.id = id;
    }
    //adds an event to the database
    public boolean addEvent(EventModel eventModel,String username){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_EVENT_DATE, eventModel.getEventDate());
        cv.put(COLUMN_EVENT_DETAILS, eventModel.getEventDetails());
        cv.put(COLUMN_EVENT_SMS, eventModel.getSMS());
        cv.put(COLUMN_EVENT_USER, username);


        long insert = db.insert(EVENT_TABLE, null, cv);
        if(insert == -1){
            return false;
        }else {
            return true;
        }
    }
    //deletes an event from the database
    public void deleteEvent(String id){//EventModel eventModel){
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(EVENT_TABLE,COLUMN_ID + " =?" ,new String[]{id});

    }
    //updates a event in the database
    public void updateEvent(EventModel eventModel, String username){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();

        cv.put(COLUMN_EVENT_DATE,eventModel.getEventDate());
        cv.put(COLUMN_EVENT_DETAILS,eventModel.getEventDetails());
        cv.put(COLUMN_EVENT_SMS, eventModel.getSMS());
        cv.put(COLUMN_EVENT_USER,username);

        db.update(EVENT_TABLE,cv,COLUMN_ID + "=" + Integer.toString(eventModel.getId()),null);
    }
    //returns all the events in the database
    public List<EventModel> getAllEvents(String username){

        List<EventModel> returnList = new ArrayList<>();
        //get data
        String queryString = "SELECT * FROM " + EVENT_TABLE + " WHERE " + COLUMN_EVENT_USER+ " =?";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString,new String[]{username});

        if(cursor.moveToFirst()){
            do{
                int eventID = cursor.getInt(0);
                String eventDate = cursor.getString(1);
                String eventDetails = cursor.getString(2);
                boolean eventSMS = cursor.getInt(3) > 0;

                EventModel newEvent = new EventModel(eventID,eventDate,eventDetails,eventSMS);
                EventScreen.ArrayofName.add(eventDate);
                returnList.add(newEvent);
            } while(cursor.moveToNext());

        } else {

        }
        cursor.close();
        db.close();
        return returnList;

    }

    //returns all the events in the database
    public List<EventModel> getAllEventsOrderByDate(String username){

        List<EventModel> returnList = new ArrayList<>();
        //get data
        //String queryString = " SELECT * FROM " + EVENT_TABLE + " WHERE " + COLUMN_EVENT_USER+ " = '" + username.trim() + "' ORDER BY " + COLUMN_EVENT_DATE;//" WHERE " + COLUMN_EVENT_USER+ " = " + username + " ORDER BY " + COLUMN_EVENT_DATE;
        String queryString = " SELECT * FROM " + EVENT_TABLE + " WHERE " + COLUMN_EVENT_USER+ " =? ORDER BY " + COLUMN_EVENT_DATE;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString,new String[]{username});

        if(cursor.moveToFirst()){
            do{
                int eventID = cursor.getInt(0);
                String eventDate = cursor.getString(1);
                String eventDetails = cursor.getString(2);
                boolean eventSMS = cursor.getInt(3) > 0;

                EventModel newEvent = new EventModel(eventID,eventDate,eventDetails,eventSMS);
                EventScreen.ArrayofName.add(eventDate);
                returnList.add(newEvent);
            } while(cursor.moveToNext());

        } else {

        }
        cursor.close();
        db.close();
        return returnList;

    }

    //returns all the events in the database
    public List<EventModel> searchEvents(String date,String username){

        List<EventModel> returnList = new ArrayList<>();
        //get data
        String queryString = "SELECT * FROM " + EVENT_TABLE + " WHERE " + COLUMN_EVENT_USER+ " =? AND " + COLUMN_EVENT_DATE + " LIKE '%" + date + "%'";

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString,new String[]{username});

        if(cursor.moveToFirst()){
            do{
                int eventID = cursor.getInt(0);
                String eventDate = cursor.getString(1);
                String eventDetails = cursor.getString(2);
                boolean eventSMS = cursor.getInt(3) > 0;

                EventModel newEvent = new EventModel(eventID,eventDate,eventDetails,eventSMS);
                EventScreen.ArrayofName.add(eventDate);
                returnList.add(newEvent);
            } while(cursor.moveToNext());

        } else {

        }
        cursor.close();
        db.close();
        return returnList;

    }

    //returns all dates from the events in the database
    public List<String> getAllDates(String username){

        List<String> returnList = new ArrayList<>();
        //get data
        String queryString = "SELECT * FROM " + EVENT_TABLE + " WHERE " + COLUMN_EVENT_USER+ " =?" ;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(queryString,new String[]{username});
        //go through the database and retrive the dates
        if(cursor.moveToFirst()){
            do{
                int eventID = cursor.getInt(0);
                String eventDate = cursor.getString(1);
                String eventDetails = cursor.getString(2);
                boolean eventSMS = cursor.getInt(3) > 0;

                EventModel newEvent = new EventModel(eventID,eventDate,eventDetails,eventSMS);
                returnList.add(cursor.getString(1));
                returnList.add(Integer.toString(cursor.getInt(0)));
            } while(cursor.moveToNext());

        } else {

        }
        cursor.close();
        db.close();
        return returnList;

    }
}
