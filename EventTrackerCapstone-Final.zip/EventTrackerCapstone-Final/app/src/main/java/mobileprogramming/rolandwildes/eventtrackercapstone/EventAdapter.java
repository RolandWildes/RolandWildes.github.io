package mobileprogramming.rolandwildes.eventtrackercapstone;
/**
 * The following code creates a view for the events that will be then placed in the event view. Takes an event and sets the date field
 * to the description for the event cards.
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

//Structure for the events used in the database and converting the data to a adapter structure
public class EventAdapter extends ArrayAdapter<EventModel> {


    public EventAdapter(@NonNull Context context, List<EventModel> eventArrayList) { //was ArrayList
        super(context, 0, eventArrayList);
    }

    public Integer[] picture = {
            R.drawable.calendar
    };

    @NonNull
    @Override
    //create a adapter view for the events
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View listitemView = convertView;
        if(listitemView == null){
            listitemView = LayoutInflater.from(getContext()).inflate(R.layout.event_card, parent, false);
        }
        EventModel eventModel = getItem(position);
        TextView event_date = listitemView.findViewById(R.id.idEventGrid);

        event_date.setText(eventModel.getEventDate());

        ImageView eventImage = (ImageView) listitemView.findViewById(R.id.picture);

        eventImage.setImageResource(picture[0]);
        return listitemView;
    }
}
